import React from "react";
import "./index.css";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-indigo-600 to-pink-600 text-white py-24 px-6 text-center">
        <h1 className="text-6xl font-extrabold mb-4 tracking-tight">HackSphere 2025</h1>
        <p className="text-2xl mb-6 italic">Code. Create. Conquer.</p>
        <p className="mb-8 text-lg">June 20–22, 2025 – Online</p>
        <button className="bg-white text-indigo-600 font-semibold px-8 py-4 rounded-full hover:bg-indigo-100 transition text-lg">
          Register Now
        </button>
      </section>

      {/* About Section */}
      <section className="py-20 px-6 max-w-4xl mx-auto text-center">
        <h2 className="text-4xl font-bold mb-6">About HackSphere</h2>
        <p className="mb-6 text-lg leading-relaxed">
          HackSphere 2025 is a 48-hour global online hackathon uniting coders, designers,
          and tech enthusiasts from across the globe to collaborate and build innovative
          solutions to real-world problems. It's more than just coding — it's a celebration
          of creativity, teamwork, and technology.
        </p>
        <p className="text-lg leading-relaxed">
          Whether you're a beginner looking to learn or a seasoned hacker ready to win, HackSphere
          provides the space, support, and challenges to help you grow. Dive in, make connections,
          and leave your mark!
        </p>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white text-center py-6 mt-auto">
        © 2025 HackSphere. All rights reserved.
      </footer>
    </div>
  );
}